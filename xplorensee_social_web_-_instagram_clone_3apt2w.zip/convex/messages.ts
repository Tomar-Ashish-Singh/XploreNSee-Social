import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getOrCreateConversation = mutation({
  args: {
    otherUserId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (userId === args.otherUserId) {
      throw new Error("Cannot create conversation with yourself");
    }

    // Check if conversation already exists
    const allConversations = await ctx.db.query("conversations").collect();
    const existingConversation = allConversations.find((conv) => {
      return conv.participants.length === 2 &&
        ((conv.participants[0] === userId && conv.participants[1] === args.otherUserId) ||
         (conv.participants[0] === args.otherUserId && conv.participants[1] === userId));
    });

    if (existingConversation) {
      return existingConversation._id;
    }

    // Create new conversation
    const conversationId = await ctx.db.insert("conversations", {
      participants: [userId, args.otherUserId],
      lastMessageTime: Date.now(),
    });

    return conversationId;
  },
});

export const sendMessage = mutation({
  args: {
    conversationId: v.id("conversations"),
    content: v.string(),
    messageType: v.union(v.literal("text"), v.literal("image")),
    imageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation) {
      throw new Error("Conversation not found");
    }

    if (!conversation.participants.includes(userId)) {
      throw new Error("Not authorized to send messages in this conversation");
    }

    const messageId = await ctx.db.insert("messages", {
      conversationId: args.conversationId,
      senderId: userId,
      content: args.content,
      messageType: args.messageType,
      imageId: args.imageId,
    });

    // Update conversation's last message info
    await ctx.db.patch(args.conversationId, {
      lastMessageTime: Date.now(),
      lastMessage: args.content,
    });

    return messageId;
  },
});

export const getConversations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const allConversations = await ctx.db.query("conversations").collect();
    const userConversations = allConversations.filter((conv) => 
      conv.participants.includes(userId)
    );

    // Sort by last message time
    userConversations.sort((a, b) => b.lastMessageTime - a.lastMessageTime);

    const conversationsWithDetails = await Promise.all(
      userConversations.map(async (conversation) => {
        const otherUserId = conversation.participants.find((id) => id !== userId);
        if (!otherUserId) return null;

        const otherUser = await ctx.db.get(otherUserId);
        const otherProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user", (q) => q.eq("userId", otherUserId))
          .unique();

        const profileImageUrl = otherProfile?.profileImageId
          ? await ctx.storage.getUrl(otherProfile.profileImageId)
          : null;

        return {
          ...conversation,
          otherUser: {
            id: otherUserId,
            name: otherUser?.name || "Unknown",
            username: otherProfile?.username || otherUser?.email?.split("@")[0] || "user",
            profileImageUrl,
          },
        };
      })
    );

    return conversationsWithDetails.filter(Boolean);
  },
});

export const getMessages = query({
  args: {
    conversationId: v.id("conversations"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || !conversation.participants.includes(userId)) {
      return [];
    }

    const messages = await ctx.db
      .query("messages")
      .withIndex("by_conversation", (q) => q.eq("conversationId", args.conversationId))
      .order("asc")
      .collect();

    const messagesWithDetails = await Promise.all(
      messages.map(async (message) => {
        const sender = await ctx.db.get(message.senderId);
        const senderProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user", (q) => q.eq("userId", message.senderId))
          .unique();

        const imageUrl = message.imageId
          ? await ctx.storage.getUrl(message.imageId)
          : null;

        return {
          ...message,
          sender: {
            name: sender?.name || "Unknown",
            username: senderProfile?.username || sender?.email?.split("@")[0] || "user",
          },
          imageUrl,
          isFromCurrentUser: message.senderId === userId,
        };
      })
    );

    return messagesWithDetails;
  },
});
