import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createOrUpdateProfile = mutation({
  args: {
    username: v.string(),
    bio: v.optional(v.string()),
    profileImageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      await ctx.db.patch(existingProfile._id, {
        username: args.username,
        bio: args.bio,
        profileImageId: args.profileImageId,
      });
      return existingProfile._id;
    } else {
      return await ctx.db.insert("userProfiles", {
        userId,
        username: args.username,
        bio: args.bio,
        profileImageId: args.profileImageId,
        postsCount: 0,
        followersCount: 0,
        followingCount: 0,
        isPrivate: false,
      });
    }
  },
});

export const getCurrentUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) {
      return null;
    }

    const profileImageUrl = profile.profileImageId 
      ? await ctx.storage.getUrl(profile.profileImageId) 
      : null;

    return {
      ...profile,
      profileImageUrl,
    };
  },
});

export const followUser = mutation({
  args: {
    targetUserId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (userId === args.targetUserId) {
      throw new Error("Cannot follow yourself");
    }

    const existingFollow = await ctx.db
      .query("follows")
      .withIndex("by_relationship", (q) => 
        q.eq("followerId", userId).eq("followingId", args.targetUserId)
      )
      .unique();

    if (existingFollow) {
      // Unfollow
      await ctx.db.delete(existingFollow._id);
      
      // Update counts
      const followerProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .unique();
      
      const followingProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", args.targetUserId))
        .unique();

      if (followerProfile) {
        await ctx.db.patch(followerProfile._id, {
          followingCount: followerProfile.followingCount - 1,
        });
      }

      if (followingProfile) {
        await ctx.db.patch(followingProfile._id, {
          followersCount: followingProfile.followersCount - 1,
        });
      }
    } else {
      // Follow
      await ctx.db.insert("follows", {
        followerId: userId,
        followingId: args.targetUserId,
      });

      // Update counts
      const followerProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .unique();
      
      const followingProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", args.targetUserId))
        .unique();

      if (followerProfile) {
        await ctx.db.patch(followerProfile._id, {
          followingCount: followerProfile.followingCount + 1,
        });
      }

      if (followingProfile) {
        await ctx.db.patch(followingProfile._id, {
          followersCount: followingProfile.followersCount + 1,
        });
      }
    }
  },
});
