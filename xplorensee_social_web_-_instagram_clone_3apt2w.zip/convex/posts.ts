import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createPost = mutation({
  args: {
    caption: v.string(),
    imageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const postId = await ctx.db.insert("posts", {
      userId,
      caption: args.caption,
      imageId: args.imageId,
      likes: 0,
      likedBy: [],
    });

    // Update user's posts count
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
    
    if (profile) {
      await ctx.db.patch(profile._id, {
        postsCount: profile.postsCount + 1,
      });
    }

    return postId;
  },
});

export const getFeed = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    // Get posts from followed users and own posts
    const follows = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", userId))
      .collect();

    const followingIds = follows.map((f) => f.followingId);
    followingIds.push(userId); // Include own posts

    const posts = await ctx.db
      .query("posts")
      .order("desc")
      .take(50);

    const feedPosts = posts.filter((post) => followingIds.includes(post.userId));

    // Get user profiles and image URLs for posts
    const postsWithDetails = await Promise.all(
      feedPosts.map(async (post) => {
        const user = await ctx.db.get(post.userId);
        const profile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user", (q) => q.eq("userId", post.userId))
          .unique();
        
        const imageUrl = post.imageId ? await ctx.storage.getUrl(post.imageId) : null;
        const profileImageUrl = profile?.profileImageId 
          ? await ctx.storage.getUrl(profile.profileImageId) 
          : null;

        return {
          ...post,
          user: {
            name: user?.name || "Unknown",
            email: user?.email || "",
            username: profile?.username || user?.email?.split("@")[0] || "user",
            profileImageUrl,
          },
          imageUrl,
          isLikedByCurrentUser: post.likedBy.includes(userId),
        };
      })
    );

    return postsWithDetails;
  },
});

export const likePost = mutation({
  args: {
    postId: v.id("posts"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const post = await ctx.db.get(args.postId);
    if (!post) {
      throw new Error("Post not found");
    }

    const isLiked = post.likedBy.includes(userId);
    
    if (isLiked) {
      // Unlike
      await ctx.db.patch(args.postId, {
        likes: post.likes - 1,
        likedBy: post.likedBy.filter((id) => id !== userId),
      });
    } else {
      // Like
      await ctx.db.patch(args.postId, {
        likes: post.likes + 1,
        likedBy: [...post.likedBy, userId],
      });
    }
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});
