import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getUserProfile = query({
  args: {
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) {
      return null;
    }

    // Check if current user is blocked by the target user
    const isBlocked = await ctx.db
      .query("blockedUsers")
      .withIndex("by_relationship", (q) =>
        q.eq("blockerId", args.userId).eq("blockedId", currentUserId)
      )
      .unique();

    if (isBlocked) {
      return null;
    }

    const user = await ctx.db.get(args.userId);
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();

    if (!profile) {
      return null;
    }

    const profileImageUrl = profile.profileImageId
      ? await ctx.storage.getUrl(profile.profileImageId)
      : null;

    // Check if current user follows this user
    const isFollowing = await ctx.db
      .query("follows")
      .withIndex("by_relationship", (q) =>
        q.eq("followerId", currentUserId).eq("followingId", args.userId)
      )
      .unique();

    // Check if current user has blocked this user
    const hasBlocked = await ctx.db
      .query("blockedUsers")
      .withIndex("by_relationship", (q) =>
        q.eq("blockerId", currentUserId).eq("blockedId", args.userId)
      )
      .unique();

    // Get user's posts (if not private or if following)
    let posts: any[] = [];
    if (!(profile.isPrivate ?? false) || isFollowing || currentUserId === args.userId) {
      const userPosts = await ctx.db
        .query("posts")
        .withIndex("by_user", (q) => q.eq("userId", args.userId))
        .order("desc")
        .take(12);

      posts = await Promise.all(
        userPosts.map(async (post) => {
          const imageUrl = post.imageId ? await ctx.storage.getUrl(post.imageId) : null;
          return {
            ...post,
            imageUrl,
          };
        })
      );
    }

    return {
      ...profile,
      user: {
        name: user?.name || "Unknown",
        email: user?.email || "",
      },
      profileImageUrl,
      isFollowing: !!isFollowing,
      hasBlocked: !!hasBlocked,
      isCurrentUser: currentUserId === args.userId,
      posts,
    };
  },
});

export const blockUser = mutation({
  args: {
    targetUserId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (userId === args.targetUserId) {
      throw new Error("Cannot block yourself");
    }

    const existingBlock = await ctx.db
      .query("blockedUsers")
      .withIndex("by_relationship", (q) =>
        q.eq("blockerId", userId).eq("blockedId", args.targetUserId)
      )
      .unique();

    if (existingBlock) {
      // Unblock
      await ctx.db.delete(existingBlock._id);
    } else {
      // Block
      await ctx.db.insert("blockedUsers", {
        blockerId: userId,
        blockedId: args.targetUserId,
      });

      // Remove follow relationships
      const followRelationship1 = await ctx.db
        .query("follows")
        .withIndex("by_relationship", (q) =>
          q.eq("followerId", userId).eq("followingId", args.targetUserId)
        )
        .unique();

      const followRelationship2 = await ctx.db
        .query("follows")
        .withIndex("by_relationship", (q) =>
          q.eq("followerId", args.targetUserId).eq("followingId", userId)
        )
        .unique();

      if (followRelationship1) {
        await ctx.db.delete(followRelationship1._id);
      }
      if (followRelationship2) {
        await ctx.db.delete(followRelationship2._id);
      }

      // Update follower counts
      const userProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .unique();

      const targetProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", args.targetUserId))
        .unique();

      if (userProfile && followRelationship1) {
        await ctx.db.patch(userProfile._id, {
          followingCount: Math.max(0, userProfile.followingCount - 1),
        });
      }

      if (targetProfile && followRelationship1) {
        await ctx.db.patch(targetProfile._id, {
          followersCount: Math.max(0, targetProfile.followersCount - 1),
        });
      }

      if (userProfile && followRelationship2) {
        await ctx.db.patch(userProfile._id, {
          followersCount: Math.max(0, userProfile.followersCount - 1),
        });
      }

      if (targetProfile && followRelationship2) {
        await ctx.db.patch(targetProfile._id, {
          followingCount: Math.max(0, targetProfile.followingCount - 1),
        });
      }
    }
  },
});

export const getBlockedUsers = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const blockedRelationships = await ctx.db
      .query("blockedUsers")
      .withIndex("by_blocker", (q) => q.eq("blockerId", userId))
      .collect();

    const blockedUsers = await Promise.all(
      blockedRelationships.map(async (block) => {
        const user = await ctx.db.get(block.blockedId);
        const profile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user", (q) => q.eq("userId", block.blockedId))
          .unique();

        const profileImageUrl = profile?.profileImageId
          ? await ctx.storage.getUrl(profile.profileImageId)
          : null;

        return {
          blockId: block._id,
          userId: block.blockedId,
          name: user?.name || "Unknown",
          username: profile?.username || user?.email?.split("@")[0] || "user",
          profileImageUrl,
        };
      })
    );

    return blockedUsers;
  },
});
