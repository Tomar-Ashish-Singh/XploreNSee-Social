import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createNotification = mutation({
  args: {
    userId: v.id("users"),
    type: v.union(
      v.literal("like"),
      v.literal("comment"),
      v.literal("follow"),
      v.literal("message")
    ),
    fromUserId: v.id("users"),
    postId: v.optional(v.id("posts")),
    commentId: v.optional(v.id("comments")),
    conversationId: v.optional(v.id("conversations")),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    // Don't create notification for self
    if (args.userId === args.fromUserId) {
      return null;
    }

    // Check if user is blocked
    const isBlocked = await ctx.db
      .query("blockedUsers")
      .withIndex("by_relationship", (q) =>
        q.eq("blockerId", args.userId).eq("blockedId", args.fromUserId)
      )
      .unique();

    if (isBlocked) {
      return null;
    }

    return await ctx.db.insert("notifications", {
      ...args,
      isRead: false,
    });
  },
});

export const getNotifications = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const notifications = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(50);

    const notificationsWithDetails = await Promise.all(
      notifications.map(async (notification) => {
        const fromUser = await ctx.db.get(notification.fromUserId);
        const fromProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user", (q) => q.eq("userId", notification.fromUserId))
          .unique();

        const profileImageUrl = fromProfile?.profileImageId
          ? await ctx.storage.getUrl(fromProfile.profileImageId)
          : null;

        return {
          ...notification,
          fromUser: {
            name: fromUser?.name || "Unknown",
            username: fromProfile?.username || fromUser?.email?.split("@")[0] || "user",
            profileImageUrl,
          },
        };
      })
    );

    return notificationsWithDetails;
  },
});

export const markNotificationAsRead = mutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const notification = await ctx.db.get(args.notificationId);
    if (!notification || notification.userId !== userId) {
      throw new Error("Notification not found");
    }

    await ctx.db.patch(args.notificationId, {
      isRead: true,
    });
  },
});

export const markAllNotificationsAsRead = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const unreadNotifications = await ctx.db
      .query("notifications")
      .withIndex("by_user_unread", (q) => q.eq("userId", userId).eq("isRead", false))
      .collect();

    await Promise.all(
      unreadNotifications.map((notification) =>
        ctx.db.patch(notification._id, { isRead: true })
      )
    );
  },
});

export const getUnreadCount = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return 0;
    }

    const unreadNotifications = await ctx.db
      .query("notifications")
      .withIndex("by_user_unread", (q) => q.eq("userId", userId).eq("isRead", false))
      .collect();

    return unreadNotifications.length;
  },
});
