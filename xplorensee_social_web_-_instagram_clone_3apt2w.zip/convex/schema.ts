import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  posts: defineTable({
    userId: v.id("users"),
    imageId: v.optional(v.id("_storage")),
    caption: v.string(),
    likes: v.number(),
    likedBy: v.array(v.id("users")),
  })
    .index("by_user", ["userId"]),

  comments: defineTable({
    postId: v.id("posts"),
    userId: v.id("users"),
    text: v.string(),
  })
    .index("by_post", ["postId"])
    .index("by_user", ["userId"]),

  follows: defineTable({
    followerId: v.id("users"),
    followingId: v.id("users"),
  })
    .index("by_follower", ["followerId"])
    .index("by_following", ["followingId"])
    .index("by_relationship", ["followerId", "followingId"]),

  userProfiles: defineTable({
    userId: v.id("users"),
    username: v.string(),
    bio: v.optional(v.string()),
    profileImageId: v.optional(v.id("_storage")),
    postsCount: v.number(),
    followersCount: v.number(),
    followingCount: v.number(),
    isPrivate: v.optional(v.boolean()),
    isVerified: v.optional(v.boolean()),
  })
    .index("by_user", ["userId"])
    .index("by_username", ["username"])
    .searchIndex("search_username", {
      searchField: "username",
    }),

  conversations: defineTable({
    participants: v.array(v.id("users")),
    lastMessageTime: v.number(),
    lastMessage: v.optional(v.string()),
  })
    .index("by_participants", ["participants"])
    .index("by_last_message_time", ["lastMessageTime"]),

  messages: defineTable({
    conversationId: v.id("conversations"),
    senderId: v.id("users"),
    content: v.string(),
    messageType: v.union(v.literal("text"), v.literal("image")),
    imageId: v.optional(v.id("_storage")),
  })
    .index("by_conversation", ["conversationId"])
    .index("by_sender", ["senderId"]),

  notifications: defineTable({
    userId: v.id("users"),
    type: v.union(
      v.literal("like"),
      v.literal("comment"),
      v.literal("follow"),
      v.literal("message")
    ),
    fromUserId: v.id("users"),
    postId: v.optional(v.id("posts")),
    commentId: v.optional(v.id("comments")),
    conversationId: v.optional(v.id("conversations")),
    message: v.string(),
    isRead: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_user_unread", ["userId", "isRead"]),

  blockedUsers: defineTable({
    blockerId: v.id("users"),
    blockedId: v.id("users"),
  })
    .index("by_blocker", ["blockerId"])
    .index("by_blocked", ["blockedId"])
    .index("by_relationship", ["blockerId", "blockedId"]),

  privacySettings: defineTable({
    userId: v.id("users"),
    allowMessagesFromFollowersOnly: v.boolean(),
    allowTagging: v.boolean(),
    showOnlineStatus: v.boolean(),
    allowSearchByEmail: v.boolean(),
  })
    .index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
