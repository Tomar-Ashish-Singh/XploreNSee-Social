import { v } from "convex/values";
import { query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const searchUsers = query({
  args: {
    searchTerm: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    if (!args.searchTerm.trim()) {
      return [];
    }

    const profiles = await ctx.db
      .query("userProfiles")
      .withSearchIndex("search_username", (q) =>
        q.search("username", args.searchTerm)
      )
      .take(20);

    // Get follow status for each user
    const profilesWithFollowStatus = await Promise.all(
      profiles.map(async (profile) => {
        const user = await ctx.db.get(profile.userId);
        const isFollowing = await ctx.db
          .query("follows")
          .withIndex("by_relationship", (q) =>
            q.eq("followerId", userId).eq("followingId", profile.userId)
          )
          .unique();

        const profileImageUrl = profile.profileImageId
          ? await ctx.storage.getUrl(profile.profileImageId)
          : null;

        return {
          ...profile,
          user: {
            name: user?.name || "Unknown",
            email: user?.email || "",
          },
          profileImageUrl,
          isFollowing: !!isFollowing,
          isCurrentUser: profile.userId === userId,
        };
      })
    );

    return profilesWithFollowStatus;
  },
});

export const getSuggestedUsers = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    // Get users that the current user is not following
    const allProfiles = await ctx.db
      .query("userProfiles")
      .order("desc")
      .take(10);

    const following = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", userId))
      .collect();

    const followingIds = following.map((f) => f.followingId);
    followingIds.push(userId); // Exclude current user

    const suggestedProfiles = allProfiles.filter(
      (profile) => !followingIds.includes(profile.userId)
    );

    const profilesWithDetails = await Promise.all(
      suggestedProfiles.map(async (profile) => {
        const user = await ctx.db.get(profile.userId);
        const profileImageUrl = profile.profileImageId
          ? await ctx.storage.getUrl(profile.profileImageId)
          : null;

        return {
          ...profile,
          user: {
            name: user?.name || "Unknown",
            email: user?.email || "",
          },
          profileImageUrl,
        };
      })
    );

    return profilesWithDetails;
  },
});
