import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getPrivacySettings = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const settings = await ctx.db
      .query("privacySettings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!settings) {
      // Return default settings
      return {
        allowMessagesFromFollowersOnly: false,
        allowTagging: true,
        showOnlineStatus: true,
        allowSearchByEmail: false,
      };
    }

    return settings;
  },
});

export const updatePrivacySettings = mutation({
  args: {
    allowMessagesFromFollowersOnly: v.boolean(),
    allowTagging: v.boolean(),
    showOnlineStatus: v.boolean(),
    allowSearchByEmail: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const existingSettings = await ctx.db
      .query("privacySettings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingSettings) {
      await ctx.db.patch(existingSettings._id, args);
    } else {
      await ctx.db.insert("privacySettings", {
        userId,
        ...args,
      });
    }
  },
});

export const updateAccountPrivacy = mutation({
  args: {
    isPrivate: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) {
      throw new Error("Profile not found");
    }

    await ctx.db.patch(profile._id, {
      isPrivate: args.isPrivate,
    });
  },
});
