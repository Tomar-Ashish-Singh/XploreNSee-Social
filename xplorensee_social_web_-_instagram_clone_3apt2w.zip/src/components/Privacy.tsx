import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function Privacy({ onBack }: { onBack: () => void }) {
  const privacySettings = useQuery(api.privacy.getPrivacySettings);
  const currentProfile = useQuery(api.profiles.getCurrentUserProfile);
  const blockedUsers = useQuery(api.userProfiles.getBlockedUsers) || [];
  
  const updatePrivacySettings = useMutation(api.privacy.updatePrivacySettings);
  const updateAccountPrivacy = useMutation(api.privacy.updateAccountPrivacy);
  const unblockUser = useMutation(api.userProfiles.blockUser);

  const [settings, setSettings] = useState({
    isPrivate: currentProfile?.isPrivate ?? false,
    allowMessagesFromFollowersOnly: privacySettings?.allowMessagesFromFollowersOnly || false,
    allowTagging: privacySettings?.allowTagging ?? true,
    showOnlineStatus: privacySettings?.showOnlineStatus ?? true,
    allowSearchByEmail: privacySettings?.allowSearchByEmail || false,
  });

  const handleSaveSettings = async () => {
    try {
      await updatePrivacySettings({
        allowMessagesFromFollowersOnly: settings.allowMessagesFromFollowersOnly,
        allowTagging: settings.allowTagging,
        showOnlineStatus: settings.showOnlineStatus,
        allowSearchByEmail: settings.allowSearchByEmail,
      });

      if (settings.isPrivate !== currentProfile?.isPrivate) {
        await updateAccountPrivacy({ isPrivate: settings.isPrivate });
      }

      toast.success("Privacy settings updated!");
    } catch (error) {
      console.error("Error updating privacy settings:", error);
      toast.error("Failed to update privacy settings");
    }
  };

  const handleUnblock = async (userId: string) => {
    try {
      await unblockUser({ targetUserId: userId as any });
      toast.success("User unblocked");
    } catch (error) {
      console.error("Error unblocking user:", error);
      toast.error("Failed to unblock user");
    }
  };

  if (!privacySettings || !currentProfile) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="p-4">
      {/* Header */}
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors mr-3"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-xl font-bold">Privacy & Security</h1>
      </div>

      <div className="space-y-6">
        {/* Account Privacy */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold mb-4">Account Privacy</h3>
          
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="font-medium">Private Account</p>
              <p className="text-sm text-gray-600">Only followers can see your posts</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.isPrivate}
                onChange={(e) => setSettings({ ...settings, isPrivate: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>
        </div>

        {/* Communication */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold mb-4">Communication</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Messages from followers only</p>
                <p className="text-sm text-gray-600">Only people you follow can message you</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.allowMessagesFromFollowersOnly}
                  onChange={(e) => setSettings({ ...settings, allowMessagesFromFollowersOnly: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Allow tagging</p>
                <p className="text-sm text-gray-600">Let others tag you in posts</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.allowTagging}
                  onChange={(e) => setSettings({ ...settings, allowTagging: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Visibility */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold mb-4">Visibility</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Show online status</p>
                <p className="text-sm text-gray-600">Let others see when you're active</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showOnlineStatus}
                  onChange={(e) => setSettings({ ...settings, showOnlineStatus: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Allow search by email</p>
                <p className="text-sm text-gray-600">Let people find you using your email</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.allowSearchByEmail}
                  onChange={(e) => setSettings({ ...settings, allowSearchByEmail: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Blocked Users */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold mb-4">Blocked Users</h3>
          
          {blockedUsers.length === 0 ? (
            <p className="text-sm text-gray-600">No blocked users</p>
          ) : (
            <div className="space-y-3">
              {blockedUsers.map((user) => (
                <div key={user.blockId} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center text-white font-semibold text-xs overflow-hidden">
                      {user.profileImageUrl ? (
                        <img
                          src={user.profileImageUrl}
                          alt={user.username}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        user.username[0].toUpperCase()
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{user.username}</p>
                      <p className="text-xs text-gray-500">{user.name}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleUnblock(user.userId)}
                    className="px-3 py-1 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Unblock
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Save Button */}
        <button
          onClick={handleSaveSettings}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all"
        >
          Save Settings
        </button>
      </div>
    </div>
  );
}
