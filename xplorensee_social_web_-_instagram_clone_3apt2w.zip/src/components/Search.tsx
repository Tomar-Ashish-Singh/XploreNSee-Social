import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

export function Search({ onViewUserProfile }: { 
  onViewUserProfile: (userId: Id<"users">) => void;
}) {
  const [searchTerm, setSearchTerm] = useState("");
  const searchResults = useQuery(api.search.searchUsers, { searchTerm }) || [];
  const suggestedUsers = useQuery(api.search.getSuggestedUsers) || [];
  const followUser = useMutation(api.profiles.followUser);

  const handleFollow = async (userId: string) => {
    try {
      await followUser({ targetUserId: userId as any });
      toast.success("Follow status updated!");
    } catch (error) {
      console.error("Error following user:", error);
      toast.error("Failed to update follow status");
    }
  };

  const displayUsers = searchTerm.trim() ? searchResults : suggestedUsers;

  return (
    <div className="p-4">
      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search users..."
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
          />
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-4">
          {searchTerm.trim() ? "Search Results" : "Suggested for You"}
        </h2>
        
        {displayUsers.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm.trim() ? "No users found" : "No suggestions available"}
            </h3>
            <p className="text-gray-500">
              {searchTerm.trim() ? "Try a different search term" : "Check back later for new users to follow"}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {displayUsers.map((user) => (
              <UserCard
                key={user._id}
                user={user}
                onFollow={() => handleFollow(user.userId)}
                onViewProfile={() => onViewUserProfile(user.userId)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function UserCard({ user, onFollow, onViewProfile }: { 
  user: any; 
  onFollow: () => void;
  onViewProfile: () => void;
}) {
  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
      <button
        onClick={onViewProfile}
        className="flex items-center space-x-3 flex-1 text-left"
      >
        <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center text-white font-semibold overflow-hidden">
          {user.profileImageUrl ? (
            <img
              src={user.profileImageUrl}
              alt={user.username}
              className="w-12 h-12 rounded-full object-cover"
            />
          ) : (
            user.username[0].toUpperCase()
          )}
        </div>
        <div>
          <div className="flex items-center space-x-1">
            <p className="font-semibold text-sm">{user.username}</p>
            {user.isPrivate && (
              <svg className="w-3 h-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            )}
          </div>
          <p className="text-xs text-gray-500">{user.user.name}</p>
          {user.bio && (
            <p className="text-xs text-gray-600 mt-1">{user.bio}</p>
          )}
          <div className="flex items-center space-x-4 mt-1">
            <span className="text-xs text-gray-500">{user.postsCount} posts</span>
            <span className="text-xs text-gray-500">{user.followersCount} followers</span>
          </div>
        </div>
      </button>
      
      {!user.isCurrentUser && (
        <button
          onClick={onFollow}
          className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
            user.isFollowing
              ? "bg-gray-200 text-gray-700 hover:bg-gray-300"
              : "bg-purple-600 text-white hover:bg-purple-700"
          }`}
        >
          {user.isFollowing ? "Unfollow" : "Follow"}
        </button>
      )}
    </div>
  );
}
