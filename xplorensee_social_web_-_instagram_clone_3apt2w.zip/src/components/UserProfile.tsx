import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

export function UserProfile({ 
  userId, 
  onBack, 
  onViewUserProfile 
}: { 
  userId: Id<"users">; 
  onBack: () => void;
  onViewUserProfile: (userId: Id<"users">) => void;
}) {
  const userProfile = useQuery(api.userProfiles.getUserProfile, { userId });
  const followUser = useMutation(api.profiles.followUser);
  const blockUser = useMutation(api.userProfiles.blockUser);
  const getOrCreateConversation = useMutation(api.messages.getOrCreateConversation);

  if (!userProfile) {
    return (
      <div className="p-4">
        <button
          onClick={onBack}
          className="mb-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div className="text-center py-12">
          <p className="text-gray-500">User not found or profile is private</p>
        </div>
      </div>
    );
  }

  const handleFollow = async () => {
    try {
      await followUser({ targetUserId: userId });
      toast.success(userProfile.isFollowing ? "Unfollowed user" : "Following user");
    } catch (error) {
      console.error("Error following user:", error);
      toast.error("Failed to update follow status");
    }
  };

  const handleBlock = async () => {
    try {
      await blockUser({ targetUserId: userId });
      toast.success(userProfile.hasBlocked ? "User unblocked" : "User blocked");
      if (!userProfile.hasBlocked) {
        onBack();
      }
    } catch (error) {
      console.error("Error blocking user:", error);
      toast.error("Failed to block user");
    }
  };

  const handleMessage = async () => {
    try {
      await getOrCreateConversation({ otherUserId: userId });
      toast.success("Conversation started");
    } catch (error) {
      console.error("Error creating conversation:", error);
      toast.error("Failed to start conversation");
    }
  };

  return (
    <div className="p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={handleMessage}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </button>
          
          <div className="relative">
            <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Profile Info */}
      <div className="text-center mb-6">
        <div className="w-24 h-24 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4 overflow-hidden">
          {userProfile.profileImageUrl ? (
            <img
              src={userProfile.profileImageUrl}
              alt={userProfile.username}
              className="w-full h-full object-cover"
            />
          ) : (
            userProfile.username[0].toUpperCase()
          )}
        </div>
        
        <div className="flex items-center justify-center space-x-2 mb-2">
          <h1 className="text-xl font-bold">{userProfile.username}</h1>
          {userProfile.isVerified && (
            <svg className="w-5 h-5 text-blue-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          )}
          {userProfile.isPrivate && (
            <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          )}
        </div>
        
        <p className="text-gray-600 mb-4">{userProfile.user.name}</p>
        
        {userProfile.bio && (
          <p className="text-sm text-gray-700 mb-4">{userProfile.bio}</p>
        )}

        {/* Stats */}
        <div className="flex justify-center space-x-8 mb-6">
          <div className="text-center">
            <div className="font-bold text-lg">{userProfile.postsCount}</div>
            <div className="text-sm text-gray-600">Posts</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-lg">{userProfile.followersCount}</div>
            <div className="text-sm text-gray-600">Followers</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-lg">{userProfile.followingCount}</div>
            <div className="text-sm text-gray-600">Following</div>
          </div>
        </div>

        {/* Action Buttons */}
        {!userProfile.isCurrentUser && (
          <div className="flex space-x-3 mb-6">
            <button
              onClick={handleFollow}
              className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-colors ${
                userProfile.isFollowing
                  ? "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  : "bg-purple-600 text-white hover:bg-purple-700"
              }`}
            >
              {userProfile.isFollowing ? "Unfollow" : "Follow"}
            </button>
            
            <button
              onClick={handleBlock}
              className="px-4 py-2 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors"
            >
              {userProfile.hasBlocked ? "Unblock" : "Block"}
            </button>
          </div>
        )}
      </div>

      {/* Posts Grid */}
      <div>
        <h3 className="font-semibold mb-4">Posts</h3>
        {userProfile.posts.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-gray-500">
              {userProfile.isPrivate && !userProfile.isFollowing 
                ? "This account is private" 
                : "No posts yet"
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-1">
            {userProfile.posts.map((post) => (
              <div key={post._id} className="aspect-square bg-gray-200 rounded-lg overflow-hidden">
                {post.imageUrl ? (
                  <img
                    src={post.imageUrl}
                    alt="Post"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-400 to-pink-400">
                    <span className="text-white text-xs font-medium text-center p-2">
                      {post.caption.substring(0, 50)}...
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
