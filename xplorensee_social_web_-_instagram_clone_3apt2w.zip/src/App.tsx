import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Feed } from "./components/Feed";
import { CreatePost } from "./components/CreatePost";
import { ProfileSetup } from "./components/ProfileSetup";
import { Search } from "./components/Search";
import { Messages } from "./components/Messages";
import { Notifications } from "./components/Notifications";
import { UserProfile } from "./components/UserProfile";
import { Privacy } from "./components/Privacy";
import { useState } from "react";
import { Id } from "../convex/_generated/dataModel";

export default function App() {
  const [currentView, setCurrentView] = useState<"feed" | "create" | "profile" | "search" | "messages" | "notifications" | "userProfile" | "privacy">("feed");
  const [selectedUserId, setSelectedUserId] = useState<Id<"users"> | null>(null);

  const handleViewUserProfile = (userId: Id<"users">) => {
    setSelectedUserId(userId);
    setCurrentView("userProfile");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Authenticated>
        <Header 
          currentView={currentView} 
          setCurrentView={setCurrentView}
          onViewUserProfile={handleViewUserProfile}
        />
        <main className="max-w-md mx-auto bg-white min-h-screen">
          <Content 
            currentView={currentView} 
            selectedUserId={selectedUserId}
            onViewUserProfile={handleViewUserProfile}
            setCurrentView={setCurrentView}
          />
        </main>
      </Authenticated>
      
      <Unauthenticated>
        <div className="min-h-screen flex flex-col bg-gradient-to-br from-purple-400 via-pink-500 to-red-500">
          <header className="text-center py-8">
            <h1 className="text-4xl font-bold text-white mb-2">XploreNsee</h1>
            <p className="text-white/90 text-lg">Social Web</p>
          </header>
          <main className="flex-1 flex items-center justify-center p-8">
            <div className="w-full max-w-md mx-auto bg-white rounded-lg shadow-xl p-8">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Welcome Back</h2>
                <p className="text-gray-600">Sign in to explore and share</p>
              </div>
              <SignInForm />
            </div>
          </main>
        </div>
      </Unauthenticated>
      
      <Toaster />
    </div>
  );
}

function Header({ currentView, setCurrentView, onViewUserProfile }: {
  currentView: string;
  setCurrentView: (view: "feed" | "create" | "profile" | "search" | "messages" | "notifications" | "userProfile" | "privacy") => void;
  onViewUserProfile: (userId: Id<"users">) => void;
}) {
  const unreadCount = useQuery(api.notifications.getUnreadCount) || 0;

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
        <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          XploreNsee
        </h1>
        
        <nav className="flex items-center space-x-1">
          <button
            onClick={() => setCurrentView("feed")}
            className={`p-2 rounded-lg transition-colors ${
              currentView === "feed" ? "bg-purple-100 text-purple-600" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <HomeIcon />
          </button>
          <button
            onClick={() => setCurrentView("search")}
            className={`p-2 rounded-lg transition-colors ${
              currentView === "search" ? "bg-purple-100 text-purple-600" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <SearchIcon />
          </button>
          <button
            onClick={() => setCurrentView("create")}
            className={`p-2 rounded-lg transition-colors ${
              currentView === "create" ? "bg-purple-100 text-purple-600" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <PlusIcon />
          </button>
          <button
            onClick={() => setCurrentView("messages")}
            className={`p-2 rounded-lg transition-colors ${
              currentView === "messages" ? "bg-purple-100 text-purple-600" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <MessageIcon />
          </button>
          <button
            onClick={() => setCurrentView("notifications")}
            className={`p-2 rounded-lg transition-colors relative ${
              currentView === "notifications" ? "bg-purple-100 text-purple-600" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <BellIcon />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setCurrentView("profile")}
            className={`p-2 rounded-lg transition-colors ${
              currentView === "profile" ? "bg-purple-100 text-purple-600" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <UserIcon />
          </button>
          <SignOutButton />
        </nav>
      </div>
    </header>
  );
}

function Content({ currentView, selectedUserId, onViewUserProfile, setCurrentView }: { 
  currentView: string; 
  selectedUserId: Id<"users"> | null;
  onViewUserProfile: (userId: Id<"users">) => void;
  setCurrentView: (view: "feed" | "create" | "profile" | "search" | "messages" | "notifications" | "userProfile" | "privacy") => void;
}) {
  const profile = useQuery(api.profiles.getCurrentUserProfile);

  if (profile === undefined) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!profile && currentView !== "profile") {
    return <ProfileSetup />;
  }

  switch (currentView) {
    case "create":
      return <CreatePost />;
    case "profile":
      return <ProfileSetup onNavigateToPrivacy={() => setCurrentView("privacy")} />;
    case "search":
      return <Search onViewUserProfile={onViewUserProfile} />;
    case "messages":
      return <Messages />;
    case "notifications":
      return <Notifications onViewUserProfile={onViewUserProfile} />;
    case "userProfile":
      return selectedUserId ? (
        <UserProfile 
          userId={selectedUserId} 
          onBack={() => setCurrentView("feed")}
          onViewUserProfile={onViewUserProfile}
        />
      ) : (
        <Feed onViewUserProfile={onViewUserProfile} />
      );
    case "privacy":
      return <Privacy onBack={() => setCurrentView("profile")} />;
    default:
      return <Feed onViewUserProfile={onViewUserProfile} />;
  }
}

function HomeIcon() {
  return (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  );
}

function MessageIcon() {
  return (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
    </svg>
  );
}

function BellIcon() {
  return (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
    </svg>
  );
}

function UserIcon() {
  return (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  );
}
